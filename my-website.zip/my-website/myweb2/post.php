<?php

$user = "hilman";
$password = "12345";

if (isset($_POST['submit'])) {
    if ($_POST['nama']  == $user &&
        $_POST['password'] == $password) {
       
        header("Location: index.php?nama=$user&password=$password");
    }else {
        echo "nama atau password salah";
    }
}

?>

<form action="index.php" method="post">
    <p>masukan nama <input type="text" name="nama"></p>
    <p>masukan password <input type="password" name="password"></p>
    <input type="submit" name="submit" value="kirim">
</form>